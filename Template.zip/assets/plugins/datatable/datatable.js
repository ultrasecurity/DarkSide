$(function(e) {
	$('#example').DataTable();
} );