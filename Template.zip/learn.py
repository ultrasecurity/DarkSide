from bs4 import BeautifulSoup as bs
import requests, re, random, json

ids = []
def getVideos(resp):
    for i in re.findall('((?<=(v|V)/)|(?<=be/)|(?<=(\?|\&)v=)|(?<=embed/))([\w-]+)',resp):
        id_ = i[3]
        if len(re.findall('[\d\w\_\-]{5,}',id_)) != 0:
            ids.append(id_)
channels = [
    'https://www.youtube.com/channel/UC286ntgASMskhPIJQebJVvA/videos',
    'https://www.youtube.com/user/OpenSecurityTraining/videos',
    'https://www.youtube.com/user/DEFCONConference/videos',
    'https://www.youtube.com/channel/UCHvUTfxL_9bNQgqzekPWHtg/videos',
    'https://www.youtube.com/user/L4DL4D2EUROPE/videos',
    'https://www.youtube.com/channel/UCAKbr5-LO1jB5hEtac4DwQA/videos'
]

for ch in channels:
    r = requests.get(ch).text
    soup = bs(r,'html.parser')
    js = soup.findAll('script')[27].string.split('window["ytInitialData"]')[1]
    getVideos(js)

random.shuffle(ids)
ids = [random.choice(ids) for i in range(4)]
data = {
    'data':[

    ],
    'ok': True 
}

for iD in ids:
    newData = {}
    resp = requests.get('https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v={0}&format=json'.format(iD)).json()
    newData['title'] = resp['title']
    newData['video_url'] = 'http://www.youtube.com/watch?v={0}'.format(iD)
    newData['thumbnail'] = resp['thumbnail_url']
    newData['embed'] = re.findall('src="(.*)" frameborder="0" ',resp['html'])[0]
    data['data'].append(newData)

a = (json.dumps(data))

b = open("learn.json","w")
b.write(a)
b.close()