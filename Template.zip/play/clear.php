<?php


$file = 'ip.txt';
$fp = fopen($file, 'w');

fwrite($fp,"");

fclose($fp);

?>