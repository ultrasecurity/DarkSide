from bs4 import BeautifulSoup as bs
import requests, re, json

r = requests.get('https://arzdigital.com/coins/').text
soup = bs(r,'html.parser')
tr = soup.find_all('tr')[1:]
f2e = lambda x:x.replace('۱','1').replace('۲','2').replace('۳','3').replace('۰','0').replace('۹','9').replace('۸','8').replace('۷','7').replace('۶','6').replace('۵','5').replace('۴','4')

data = {
    'data': []
}

customCurrencies = 'bitcoin | ethereum | xrp | bitcoin cash | cardano | litecoin | eos | nem | stellar | neo | iota | dash | monero | tron | tether'

for tag in tr:
    newData = {}
    tag = str(tag)
    name = re.findall(r'data-slug="([\w\-]+)"',tag)[0].replace('-',' ').lower()
    if name in customCurrencies:
        price = re.findall(r'\$[\d\,\.]+',tag)[0]
        price_toman = f2e(re.findall(r'<span><span class=".*">(.*)</span><span class="arz-toman arz-value-unit">تومان</span>',tag)[0])
        daily_change = re.findall(r'data-sort-name="daily-swing" data-sort-value="(.*)" data-sort-value-type="d"',tag)[0]
        market_cap = re.findall(r'data-sort-name="marketcap" data-sort-value="(\d+)" data-sort-value-type="d"',tag)[0]
        chart = re.findall(r'data-src="(.*)" data-src-error="default-chart\.png"',tag)[0]
        weekly_change = re.findall(r'name="weekly-swing" data-sort-value="([\-\d\.\d]+)" data-sort-value-type="d"',tag)[0]
        newData['name'] = name.title()
        newData['dollar_price'] = price
        newData['toman_price'] = price_toman
        newData['daily_change'] = daily_change
        newData['market_cap'] = market_cap
        newData['weekly_change'] = weekly_change
        newData['chart_url'] = chart
        data['data'].append(newData)

        
a = (json.dumps(data).replace("Xrp","Ripple"))

o = open("crypto.json","w")
o.write(a)
o.close()