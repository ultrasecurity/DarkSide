import re, requests, json, random

sess = requests.session()

ids = []
channels = [
        'https://www.youtube.com/channel/UC286ntgASMskhPIJQebJVvA/videos',
        'https://www.youtube.com/user/OpenSecurityTraining/videos',
        'https://www.youtube.com/user/DEFCONConference/videos',
        'https://www.youtube.com/channel/UCHvUTfxL_9bNQgqzekPWHtg/videos',
        'https://www.youtube.com/user/L4DL4D2EUROPE/videos',
        'https://www.youtube.com/channel/UCAKbr5-LO1jB5hEtac4DwQA/videos',
        'https://www.youtube.com/channel/UCO8iviFPYxykxTG1M7XdMKw/videos',
        'https://www.youtube.com/channel/UC4dq5EWtlm5qwTcwCfJNUWw/videos',
        'https://www.youtube.com/c/DANIDepp/videos',
        
    ]

for ch in channels:
    r = sess.get(ch).text
    for i in re.findall(r'((?<=(v|V)/)|(?<=be/)|(?<=(\?|\&)v=)|(?<=embed/))([\w-]+)',r):
        id_ = i[3]
        if len(re.findall(r'^[\w\_\-]{5,}$',id_)) != 0:
            ids.append(id_)

random.shuffle(ids)
ids = [random.choice(ids) for i in range(6)]

info = {'status':'ok','data':[]}
cnt = 0
for iD in ids:
    newData = {}
    resp = sess.get('https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v={0}&format=json'.format(iD))
    resp = resp.json()
    newData['title']  = resp['title']
    newData['video_url'] = 'http://www.youtube.com/watch?v={0}'.format(iD)
    newData['thumbnail'] = resp['thumbnail_url']
    info['data'].append(newData)

a =  json.dumps(info)
c = open("learn.json","w")
c.write(a)
c.close()