import requests, re, json
from bs4 import BeautifulSoup as bs


def getDesc(url):
    res = requests.get(url,headers={'Accept': '*/*','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'}).text
    parse = bs(res,'html.parser').findAll('meta',{'name':'description'})[0]['content']
    return str(parse)

r = requests.get('https://thehackernews.com/',headers={'Accept': '*/*','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'}).text

soup = bs(r,'html.parser')
data = {
    'data' : []
}
for element in soup.find_all('div',class_='body-post clear'):
    element = str(element)
    link = re.findall(r'<a class="story-link" href="(.*)">',element)[0]
    title = re.findall(r'<img alt="(.*)" class="home-img-src lazyload"',element)[0]
    desc = getDesc(link)
    image = re.findall(r'" src="https://(.*)"/>',element)[0]
    newData = {}
    newData['url'] = link
    newData['image'] = image
    newData['title'] = title
    newData['description'] = desc
    data['data'].append(newData)
a = (json.dumps(data))

b = open("news.json","w")
b.write(a)
b.close()